"""
RECORD CHECK  -  my version
===========================

Name  : Veer Sanjay Nanwani
Lane  :  AI 
Date  : 03/10/2026
"""
label = input("Enter hostname: ")
used = float(input("Enter GB used: "))
total = float(input("Enter GB total: "))

if used > total:
    status = "OVER LIMIT"
else:
    status = "OK"

print()
print("=" * 34)
print(f"  RECORD CHECK  -  {label}")
print("=" * 34)
print(f"Used   : {used:>8.0f}")
print(f"Total  : {total:>8.0f}")
print(f"Status : {status:>8}")
print("=" * 34)


over_limit_count = 0

while True:
    label = input("Enter label ('quit' to finish): ").strip()

    if label.lower() == "quit":
        break

    value = float(input("Enter value: "))
    limit = float(input("Enter limit: "))

    difference = limit - value
    percent = (difference / limit) * 100
    used_percent = (value / limit) * 100

    if used_percent >= 100:
        status = "OVER LIMIT"
        over_limit_count += 1
    elif used_percent >= 90:
        status = "WARNING"
    else:
        status = "OK"

    print()
    print("=" * 34)
    print(f"  RECORD CHECK  -  {label}")
    print("=" * 34)
    print(f"Label   : {label}")
    print(f"Value   : {value:>10.2f}")
    print(f"Limit   : {limit:>10.2f}")
    print(f"Diff.   : {difference:>8.2f}")
    print(f"Percent : {percent:>8.2f}%")
    print(f"Status  : {status}")
    print("=" * 34)

print()
print(f"Records over limit: {over_limit_count}")